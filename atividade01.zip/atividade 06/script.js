const area = document.getElementById('area');
// cria uma variável e puxa o id "area"

const lista = document.createElement('ul');
// 

const input= document.querySelector(".formulario input") ;
// cria uma variável e puxa o id "formulario input"

const criar = document.querySelector(".formulario button");
// cria uma variável e puxa o id "formulario button"

let atividades = [];
// 

let proximoId = 1; //sabe qual será o id

lista.id = lista-atividades;
// 

area.appendChild(lista);
// 

function novaAtividade(atividade) {
    // 
    const modelo = document.createElement('li');
    // 
    modelo.classList.add('atividade');
    // 

    const tarefa = {
        id: proximoId++,
        completo: false,
        nome: atividade
        // 
    };
    // 
    modelo.innerHTML = `<div class= 'card-atividade card-${atividades.length}'>${criarHtmlTarefa(tarefa, atividades.length)}</div>`;
    // 
    lista.appendChild(modelo);
    // 

    const checkbox = document.querySelector(`#tarefa-${atividades.length}`);
    // 
    checkbox.addEventListener("change", function () {
    // 
    const indiceTarefa = this.id.split("-")[1];
    // usa o valor atual do checkbox (true se marcado, false se desmarcado)
    atividades[indiceTarefa].complete = this.checked;
    // 
    atualizarContadores();
    // 
})
// 
    document.querySelectorAll('.remove-btn').forEach(btn => btn.addEventListener('click',function () {
    
    const indice = this.dataset.index;
    atividades.splice(indice, 1);
    this.closest('li').remove();
   atualizarContadores();

}));

atividades.push(tarefa);
// 

atualizarContadores();
// 
}
// 

function criarHtmlTarefa(tarefa, indice) {
    // 
    const estacompleta = tarefa.complete ? "checked" : "";
    // 

    return `<input type="checkbox" id="tarefa-${indice}" value="${tarefa.nome}" ${estacompleta}/>
    <span>${tarefa.nome}</span>
    <button title="deletar tarefa" class="remove-btn" data-index="${indice}"><img></button>`;
    // 
}

function atualizarContadores() {
    // 
    const criadas = document.getElementById("criadas");
    // 
    const concluidas = document.getElementById("concluidas");
    // 
    criadas.innerText = atividades.length;
    // 
    concluidas.innerText = `${atividades.filter(at => at.complete).length} de ${atividades.length}`;
    // 
}

criar.addEventListener('click', function () {
    // 
    const texto = input.value.trim();
    // 
    if (texto !=="") {
        // 
        novaAtividade(texto);
        // 
    }
})

function preencherLista(){
    area.innerHTML = "";
    atividades.forEach((atividades, index)=>{
    const modelo = document.createElement('li');
    area.appendChild(modelo);
    modelo.innerHTML=`<div class= 'card-atividade card-${index}'>$
    {criarHTMLTarefa(atividade, index)}</div>`
    })
}

